  Scratch Programs for Computer Science Unplugged
                     Moti Ben-Ari

Copyright 2010 by Moti Ben-Ari. This work is licensed under the Creative
Commons Attribution-ShareAlike 3.0 License. To view a copy of this
license, visit \url{http://creativecommons.org/licenses/by-sa/3.0/}; or,
(b) send a letter to Creative Commons, 543 Howard Street, 5th Floor, San
Francisco, California, 94105, USA.

The software is distributed as a zip archive and can be downloaded from:
http://code.google.com/p/scratch-unplugged/.
Unzip the archive to a clean directory. There is a separate directory
for the programs associated with each activity and the programs are
documented in the file scratch-unplugged.txt. The programs are copyright
under the GNU General Public License; see the files copyright.txt and
gpl.txt.

These Scratch programs implement algorithms for the twelve activities in
the 2006 edition of Computer Science Unplugged written by Tim Bell, Ian
H. Witten and Mike Fellows. This document can be downloaded from
http://www.google.com/educators/activities/unpluggedTeachersDec2006.pdf.

The activies (with the directory names in parentheses) are:

1. Count the Dots--Binary Numbers (binary-numbers).
2. Colour by Numbers--Image Representation (run-length-encoding).
3. You Can Say That Again!--Text Compression (compression).
4. Card Flip Magic--Error Detection & Correction (parity).
5. Twenty Guesses--Information Theory (binary-search).
6. Battleships--Searching Algorithms (searching).
7. Lightest and Heaviest--Sorting Algorithms (sorting).
8. Beat the Clock--Sorting Networks (networks).
9. The Muddy City--Minimal Spanning Trees (spanning).
10. The Orange Game--Routing and Deadlock in Networks (routing).
11. Treasure Hunt--Finite-State Automata (finite-automata). 
12. Marching Orders--Programming Languages (programming).
