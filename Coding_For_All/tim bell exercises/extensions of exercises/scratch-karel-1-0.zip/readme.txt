         Karel the Robot in Scratch
              Moti Ben-Ari

Copyright 2010 by Moti Ben-Ari. This work is licensed under the Creative
Commons Attribution-ShareAlike 3.0 License. To view a copy of this
license, visit \url{http://creativecommons.org/licenses/by-sa/3.0/}; or,
(b) send a letter to Creative Commons, 543 Howard Street, 5th Floor, San
Francisco, California, 94105, USA.

The software is distributed as a zip archive and can be downloaded from:
http://code.google.com/p/scratch-karel/.

The programs are copyright under the GNU General Public License; see the
files copyright.txt and gpl.txt.

These programs provide a framework for implementing Karel the Robot
programs in Scratch. Since Scratch is a visual programming language as
opposed to the textual programming in Karel, the correspondence is not
precise, but the learner can experience robot programming within this
framework.

READ THE DOCUMENTATION FILE scratch-karel.txt CAREFULLY!!
